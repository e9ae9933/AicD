package io.github.e9ae9933.aicd.modifier;

@Deprecated
public abstract class NoelLongable extends NoelElement
{
	public abstract long getLong();
	public abstract void setLong(long l);
}
