package io.github.e9ae9933.aicd.packets;

public class ClientboundKeepalivePacket extends Packet
{
	@Override
	public Packet handle()
	{
		return null;
	}
}
